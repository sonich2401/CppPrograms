
struct Tri{
double x[3];
double y[3];
double mNum[2][3];
double mDem[2][3];
};
struct Matrix2D{
    double a1[];
    double a2[];
};
