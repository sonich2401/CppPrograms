#include "Struct.cpp"
/*struct Tri{};
struct Matrix2D{};
*/
